$(document).ready(function(){
    $('input').click(function(){
        $('.alert').hide();
    });
});